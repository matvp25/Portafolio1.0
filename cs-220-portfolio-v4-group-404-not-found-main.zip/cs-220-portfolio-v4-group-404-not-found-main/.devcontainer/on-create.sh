# Override the .zshrc file with config/dot.zshrc
cp .devcontainer/config/dot.zshrc ~/.zshrc

# Override the .gitconfig file with config/dot.gitconfig
cp .devcontainer/config/dot.gitconfig ~/.gitconfig
